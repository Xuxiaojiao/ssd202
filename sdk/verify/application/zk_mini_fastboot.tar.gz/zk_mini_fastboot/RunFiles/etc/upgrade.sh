killall MyPlayer
killall wpa_supplicant
killall udhcpc
sleep 1
umount /customer
sleep 1
echo end_upgrade.sh
#/ota/otaunpack -x /tmp/SigmaOTA.bin
